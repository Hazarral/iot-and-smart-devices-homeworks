import azure.functions as func
import logging
import os
from azure.iot.hub import IoTHubRegistryManager
from azure.iot.hub.models import CloudToDeviceMethod

app = func.FunctionApp(http_auth_level=func.AuthLevel.ANONYMOUS)

CONNECTION_STRING = os.environ.get("IOTHUB_CONNECTION_STRING", "HostName=dummy-hub.azure-devices.net;SharedAccessKeyName=iothubowner;SharedAccessKey=fakekey123")
DEVICE_ID = "simulated-relay-01"

@app.route(route="relay_on")
def relay_on(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Received request to turn Relay ON.')
    try:
        registry_manager = IoTHubRegistryManager(CONNECTION_STRING)
        device_method = CloudToDeviceMethod(method_name="relay_on", payload="{}")
        registry_manager.invoke_device_method(DEVICE_ID, device_method)
        return func.HttpResponse("Success: Relay is ON", status_code=200)
    except Exception as e:
        return func.HttpResponse(f"Error: {e}", status_code=500)

@app.route(route="relay_off")
def relay_off(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Received request to turn Relay OFF.')
    try:
        registry_manager = IoTHubRegistryManager(CONNECTION_STRING)
        device_method = CloudToDeviceMethod(method_name="relay_off", payload="{}")
        registry_manager.invoke_device_method(DEVICE_ID, device_method)
        return func.HttpResponse("Success: Relay is OFF", status_code=200)
    except Exception as e:
        return func.HttpResponse(f"Error: {e}", status_code=500)